const getResidentsButton = document.querySelector('#getResidentsButton');

function handleButtonClick() {
    console.log('button clicked');
}

getResidentsButton.addEventListener('click', handleButtonClick);
<button id="getResidentsButton">Get Residents</button>